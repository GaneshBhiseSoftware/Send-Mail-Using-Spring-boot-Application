package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MailControllere {

	@Autowired
	JavaMailSender javaMailSender;

	@GetMapping("/sendMail")
	public String sendMail() {

		SimpleMailMessage m = new SimpleMailMessage();

		m.setTo("shitalrk21@gmail.com");
		m.setFrom("ganeshbhisepatil83@gmail.com");

		m.setSubject("Spring boot Mail");
		m.setText("hii shital mala Tujha Number Pathav");

		javaMailSender.send(m);
		return "Mail Send Succesfully";

	}

}
